var URL = "https://fir-1c7de-default-rtdb.firebaseio.com/demoproject";
const userId = localStorage.getItem("userId");
var app = angular.module('myApp', []);
app.controller('myCtrl', function ($scope) {
    $scope.onload = function () {
        $('#fromDateModelId').attr('min', new Date().toISOString().split('T')[0]);
        $('#toDateModelId').attr('min', new Date().toISOString().split('T')[0]);
        $scope.userData = localStorage.getItem("userData");
        $scope.userData = JSON.parse($scope.userData);
        $("#viewMenuDetails").show();
        $("#viewOrderDetails").hide();
        $("#viewUserDetailsDivId").hide();
        $("#feedBackDivId").show();
        $scope.reserveTableData = [];
        $scope.userName = localStorage.getItem("userName");
        $scope.orderDetails = {};
        $scope.getFoodBookingTableData();
        $scope.menuTypeList = [{
            "imgUrl": "./image/bread-omelette.jpg",
            "title": "Bread omlet",
            "type": "nonveg",
            "mealType": "Breakfast"
        }, {
            "imgUrl": "./image/eggFry.jpg",
            "title": "Egg Fry",
            "type": "nonveg",
            "mealType": "Breakfast"
        }, {
            "imgUrl": "./image/french.jpg",
            "title": "Fruits Pancake",
            "type": "veg",
            "mealType": "Breakfast"
        }, {
            "imgUrl": "./image/smoothie-bowl.jpg",
            "title": "Smoothie Bowl",
            "type": "veg",
            "mealType": "Breakfast"
        }, {
            "imgUrl": "./image/waffels.jpeg",
            "title": "Waffels",
            "type": "veg",
            "mealType": "Breakfast"
        }, {
            "imgUrl": "./image/pancake.jpg",
            "title": "Egg Pancake",
            "type": "nonveg",
            "mealType": "Breakfast"
        }, {
            "imgUrl": "./image/veg-brkfst.webp",
            "title": "Veg Breakfast",
            "type": "veg",
            "mealType": "Breakfast"
        }, {
            "imgUrl": "./image/non-veg-brkfst.jpg",
            "title": "Nonveg Breakfast",
            "type": "nonveg",
            "mealType": "Breakfast"
        }, {
            "imgUrl": "./image/burger-nonveg-lunch.jpg",
            "title": "Chiken Burger",
            "type": "nonveg",
            "mealType": "Lunch"
        }, {
            "imgUrl": "./image/burger-veg-lunch.jpg",
            "title": "Veg Burger",
            "type": "veg",
            "mealType": "Lunch"
        }, {
            "imgUrl": "./image/chiken-non-veg-lunch.webp",
            "title": "Chiken Lunch",
            "type": "nonveg",
            "mealType": "Lunch"
        }, {
            "imgUrl": "./image/healthy-food-veg-lunch.webp",
            "title": "Chiken fry with veggies",
            "type": "nonveg",
            "mealType": "Lunch"
        }, {
            "imgUrl": "./image/Healthy-Lunch-veg.jpg",
            "title": "Healthy Lunch",
            "type": "veg",
            "mealType": "Lunch"
        }, {
            "imgUrl": "./image/pasta-egg-lunch-nonveg.avif",
            "title": "Egg Pasta",
            "type": "nonveg",
            "mealType": "Lunch"
        }, {
            "imgUrl": "./image/roti-veg-lunch.webp",
            "title": "Bread",
            "type": "veg",
            "mealType": "Lunch"
        }, {
            "imgUrl": "./image/veggie-bowl-lunch.jpg",
            "title": "Veggie Bowl",
            "type": "veg",
            "mealType": "Lunch"
        }, {
            "imgUrl": "./image/chiken-salad-dinner.jpg",
            "title": "Chiken Salad",
            "type": "nonveg",
            "mealType": "Dinner"
        }, {
            "imgUrl": "./image/chiken-veggiesfry-nonveg-dinner.jpg",
            "title": "Chiken Veggies fry",
            "type": "nonveg",
            "mealType": "Dinner"
        }, {
            "imgUrl": "./image/chikenfy-nonveg-dinner.webp",
            "title": "Grill Chiken",
            "type": "nonveg",
            "mealType": "Dinner"
        }, {
            "imgUrl": "./image/egg-dinner.jpg",
            "title": "Egg",
            "type": "nonveg",
            "mealType": "Dinner"
        }, {
            "imgUrl": "./image/spinach-sweet-potato-veg-dinner.jpg",
            "title": "Spinach Sweet Potato",
            "type": "veg",
            "mealType": "Dinner"
        }, {
            "imgUrl": "./image/veg-salad-dinner.avif",
            "title": "Veg Salad",
            "type": "veg",
            "mealType": "Dinner"
        }, {
            "imgUrl": "./image/veggies-dinner.jpg",
            "title": "Veggies",
            "type": "veg",
            "mealType": "Dinner"
        }, {
            "imgUrl": "./image/veggies-protine-veg-dinner.jpg",
            "title": "Veggies with protine",
            "type": "veg",
            "mealType": "Dinner"
        }];
        $scope.menuList = [...$scope.menuTypeList];
    }
    $(document).ready(function () {
        $('#nonvegModelId').change(function () {
            if ($(this).prop('checked') && $('#vegModelId').prop('checked')) {
                $scope.menuList = [...$scope.menuTypeList];

            } else if ($(this).prop('checked')) {
                $scope.menuList = $scope.menuTypeList.filter((obj) => { return obj.type == 'nonveg' });

            } else if (!$(this).prop('checked') && $('#vegModelId').prop('checked')) {
                $scope.menuList = $scope.menuTypeList.filter((obj) => { return obj.type == 'veg' });

            } else if (!$(this).prop('checked') && !$('#vegModelId').prop('checked')) {
                $scope.menuList = [];
            }
            $scope.$apply();
        })
        $('#vegModelId').change(function () {
            if ($(this).prop('checked') && $('#nonvegModelId').prop('checked')) {
                $scope.menuList = [...$scope.menuTypeList];

            } else if ($(this).prop('checked')) {
                $scope.menuList = $scope.menuTypeList.filter((obj) => { return obj.type == 'veg' });

            } else if (!$(this).prop('checked') && $('#nonvegModelId').prop('checked')) {
                $scope.menuList = $scope.menuTypeList.filter((obj) => { return obj.type == 'nonveg' });

            } else if (!$(this).prop('checked') && !$('#nonvegModelId').prop('checked')) {
                $scope.menuList = [];
            }
            $scope.$apply();
        })
        $('#fromDateModelId').change(function () {
            const toMinDate = new Date($(this).val());
            const todate = new Date($('#toDateModelId').val());
            const fromDate = new Date($(this).val());
            $('#toDateModelId').attr('min', toMinDate.toISOString().split('T')[0]);
            if (fromDate.getTime() > todate.getTime()) {
                $('#toDateModelId').val($(this).val());
            }
        })
    });
    $scope.getCost = function (slot, gaust) {
        //$scope.tableBook.price = slot * gaust;
    }

    $scope.bookingFood = function () {
        let isValid = true;
        if (!$('#nonvegModelId').prop('checked') && !$('#vegModelId').prop('checked')) {
            isValid = false;
            alert("Please select at least one veg or nonveg");

        } else if ($('#fromDateModelId').val() == '' || $('#toDateModelId').val() == '') {
            isValid = false;
            alert("Please select date");

        }
        if (isValid) {
            const oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
            const fromDate = new Date($('#fromDateModelId').val());
            const toDate = new Date($('#toDateModelId').val());

            const diffDays = Math.round(Math.abs((fromDate - toDate) / oneDay)) + 1;
            let reqstBody = {}
            reqstBody["request"] = "Pending";
            reqstBody["name"] = $scope.userData.userName;
            reqstBody["totalDay"] = diffDays;
            if ($('#nonvegModelId').prop('checked') && $('#vegModelId').prop('checked')) {
                reqstBody["menuType"] = "Both";

            } else if ($('#nonvegModelId').prop('checked')) {
                reqstBody["menuType"] = "Nonveg";

            } else if ($('#vegModelId').prop('checked')) {
                reqstBody["menuType"] = "Veg";
            }
            reqstBody["fromDate"] = $('#fromDateModelId').val();
            reqstBody["toDate"] = $('#toDateModelId').val();
            if (reqstBody["menuType"] == 'Both') {
                reqstBody["price"] = diffDays * 50;

            } else if (reqstBody["menuType"] == 'Nonveg') {
                reqstBody["price"] = diffDays * 30;

            } else if (reqstBody["menuType"] == 'Veg') {
                reqstBody["price"] = diffDays * 20;
            }

            $.ajax({
                type: 'post',
                contentType: "application/json",
                dataType: 'json',
                cache: false,
                url: URL + "/bookCanteenFood/" + userId + ".json",
                data: JSON.stringify(reqstBody),
                success: function (response) {
                    reqstBody = {};
                    alert("Data submitted sucessfully!!!");
                }, error: function (error) {
                    alert("Something went wrong");
                }
            });
        }
    }
    $scope.getFoodBookingTableData = function () {

        $scope.reserveTableData = [];
        $.ajax({
            type: 'get',
            contentType: "application/json",
            dataType: 'json',
            cache: false,
            url: URL + "/bookCanteenFood/" + userId + ".json",
            success: function (response) {
                for (let i in response) {
                    let tableData = response[i];
                    tableData["bookingID"] = i;
                    tableData["userId"] = userId;
                    $scope.reserveTableData.push(tableData);
                }
                $scope.$apply();
            }, error: function (error) {
                alert("Something went wrong");
            }
        });
    }

    $scope.getAdminReserveTableData = function () {
        $scope.reserveTableData = [];
        $.ajax({
            type: 'get',
            contentType: "application/json",
            dataType: 'json',
            cache: false,
            url: URL + "/bookCanteenFood.json",
            success: function (response) {
                for (let data in response) {
                    for (let x in response[data]) {
                        let tableData = response[data][x];
                        tableData["userId"] = data;
                        tableData["bookingID"] = x;
                        $scope.reserveTableData.unshift(tableData);
                    }
                }
                $scope.$apply();
            }, error: function (error) {
                alert("Something went wrong");
            }
        });
    }
    $scope.getOrderData = function (data) {
        $("#ammountId").val(data.price);
        $scope.orderDetails = data;
    }

    $scope.payBill = function () {
        if ($("#paymentModeId").val() == "") {
            alert("Please select payment mode");
        } else {
            let requestBody = {
                "request": $("#paymentModeId").val()
            }
            $.ajax({
                type: 'patch',
                contentType: "application/json",
                dataType: 'json',
                cache: false,
                url: URL + "/bookCanteenFood/" + $scope.orderDetails.userId + "/" + $scope.orderDetails.bookingID + ".json",
                data: JSON.stringify(requestBody),
                success: function (response) {
                    $('#processToPayModalId').modal('hide');
                    $scope.userName == 'ADMIN' ? $scope.getAdminReserveTableData() : $scope.getFoodBookingTableData();
                    alert("Payment sucessfully!!!");
                }, error: function (error) {
                    alert("Something went wrong");
                }
            });
        }
    }
    $scope.cancel = function (data) {
        let requestBody = { "request": "Cancel" }
        $.ajax({
            type: 'patch',
            contentType: "application/json",
            dataType: 'json',
            cache: false,
            url: URL + "/bookCanteenFood/" + data.userId + "/" + data.bookingID + ".json",
            data: JSON.stringify(requestBody),
            success: function (response) {
                $scope.userName == 'ADMIN' ? $scope.getAdminReserveTableData() : $scope.getFoodBookingTableData();
                alert("Booking Canceled!!!");
            }, error: function (error) {
                alert("Something went wrong");
            }
        });
    }
    $scope.getUserDetails = function () {
        $.ajax({
            type: 'get',
            contentType: "application/json",
            dataType: 'json',
            cache: false,
            url: URL + "/canteenRegister.json",
            success: function (response) {
                $scope.userTableData = [];
                for (let i in response) {
                    let data = response[i];
                    data["userId"] = i;
                    $scope.userTableData.push(data);
                }
                $scope.$apply();
            }, error: function (error) {
                alert("Something went wrong");
            }
        });
    }

    $scope.switchMenu = function (type, id) {
        $(".menuCls").removeClass("active");
        $('#' + id).addClass("active");
        $("#viewMenuDetails").hide();
        $("#viewOrderDetails").hide();
        $("#viewUserDetailsDivId").hide();

        if (type == "VIEW_MENU") {
            $("#viewMenuDetails").show();

        } else if (type == "ORDER") {
            $("#viewOrderDetails").show();
            $scope.userName == 'ADMIN' ? $scope.getAdminReserveTableData() : $scope.getFoodBookingTableData();

        } else if (type == "USER_DETAILS") {
            $scope.userTableData = [];
            $("#viewUserDetailsDivId").show();

            if ($scope.userName == 'ADMIN') {
                $scope.getUserDetails()
            } else {
                $scope.userTableData.push($scope.userData);

            }
        }
    }
    $scope.logout = function () {
        localStorage.removeItem("userId");
        localStorage.removeItem("userData");
        localStorage.clear();
        window.location.href = "canteenManagmentLogReg.html";
    }
});
