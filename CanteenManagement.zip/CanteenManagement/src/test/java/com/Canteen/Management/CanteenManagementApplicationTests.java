package com.Canteen.Management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CanteenManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
